class Book:
    def __init__(self, title, author, ISBN):
        """Initialize a new Book instance"""
        self._title = title
        self._author = author
        self._ISBN = ISBN
        
    def getTitle(self):
        """return the title of the book"""
        return self._title
    
    def getAuthor(self):
        """return the author of the book"""
        return self._author
    
    def getISBN(self):
        """return the ISBN of the book"""
        return self._ISBN
    
    def setTitle(self, title):
        """set the title of the book"""
        self._title = title
        
    def setAuthor(self, author):
        """set the author of the book"""
        self._author = author
        
    def setISBN(self, ISBN):
        """set the ISBN of the book"""
        self._ISBN = ISBN
        
    def displayBookInfo(self):
        """display the information about the book"""
        print(f" Title: {self._title}, Author: {self._author}, ISBN: {self._ISBN}")

class Member:
    def __init__(self, name):
        """Represent a library member who can borrow the book"""
        self._name = name
        #Initialize the initial number of books borrowed to zero
        self._borrowedBooks = []
        
    def getName(self):
        """return the name of the member"""
        return self._name
    
    def getBorrowedBooks(self):
        """return a list of borrowed books"""
        return self._borrowedBooks
    
    def setName(self, name):
        """set the name of the member"""
        self._name = name
        
    def setBorrowedBooks(self, borrowedBooks):
        """set the list of borrowed books"""
        self._borrowedBooks = borrowedBooks
        
    def borrowBook(self, book):
        """add a book to the member's borrowed books list"""
        # Check if the book has already been borrowed
        for borrowed_book in member.getBorrowedBooks():
            if borrowed_book.getISBN() == book.getISBN():
                print(f"The book '{book.getTitle()}' has already been borrowed.")
                return
        # Add the book to the borrowed books list
        member.getBorrowedBooks().append(book)

    def returnBook(self, title):
        """remove a book from the member's borrowed books list by title """
        for book in member.getBorrowedBooks():
            if book.getTitle() == title:
                member.getBorrowedBooks().remove(book)
                return
        # If the book is not found, print a hint for user
        print(f"The book '{title}' has been returned or does not exit.")

    def displayBorrowedBooks(self):
        """display all borrowed books by the member"""
        #use counter to inidcate the book's serial number, initialize it to 1
        counter = 1
        print(f"Books borrowed by {member.getName()}:")
        for book in member.getBorrowedBooks():
            #make the end of the output with no "/n"
            print(f"{counter}.", end = "")
            book.displayBookInfo()
            counter = counter + 1

# main program
member_name = input("Enter the member's name: ")
member = Member(member_name)
#member.setName(member_name)
#Use the capitalized result of the input as the loop condition
borrowCheck = input("Do you want to borrow a book (\"Y\" to continue, others to stop)? ").upper()
while borrowCheck == "Y":
    book_title = input("Enter the book title: ")
    book_author = input("Enter the author's name: ")
    book_ISBN = input("Enter the ISBN number: ")
    #Ensure all fields are filled with no empty place
    while book_title == "" or book_author == "" or book_ISBN == "":
        print("Error: All fields must be filled. Please enter again!")
        book_title = input("Enter the book title: ")
        book_author= input("Enter the author's name: ")
        book_ISBN = input("Enter the ISBN number: ")
    #Create a new book instance and add it to the borrowed books
    book = Book(book_title, book_author, book_ISBN)
    #add the book into the list
    member.borrowBook(book)
    #resit the input hint to tip the user
    borrowCheck = input("Do you want to borrow another book (\"Y\" to continue, others to stop)? ").upper()
#display all books that has been borrowed by the member
member.displayBorrowedBooks()
#Use the capitalized result of the input as the loop condition
returnCheck = input("Do you want to return a book (\"Y\" to continue, others to stop)? ").upper()
while returnCheck == "Y":
    title = input("Enter the title of the book to return: ")
    while title == "":
        print("The enter title cannot be empty, please enter again!")
    #return the book by the entering title
    member.returnBook(title)
    #resit the input hint to tip the user
    returnCheck = input("Do you want to return another book (\"Y\" to continue, others to stop)? ").upper()
#display the books that has been borrowed after returning books operation
member.displayBorrowedBooks()




