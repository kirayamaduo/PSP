def addString(stringList, string):
    """
    Add a string to the end of a list.
    """
    stringList.append(string)
    return stringList

def deleteString(stringList, string):
    """
    Delete all occurrences of a specified string from a list.
    """
    # AssertionError: if the string is not in the stringList.
    assert string in stringList, "The string must be in the stringList."
    while string in stringList:
        stringList.remove(string)
    return stringList

def searchString(stringList, string):
    """
    Search for all occurrences of a specified string in a list and return their positions.
    """
    # AssertionError: if the string is not in the stringList.a
    assert string in stringList, "The string must be in the stringList."
    positions = []# Initializes an empty list to store the location found
    for i in range(len(stringList)):
        if stringList[i] == string:
            positions.append(i)
    return positions

def replaceString(stringList, oldString, newString):
    """
    Replace all occurrences of a specified old string with a new string in the list.
    """
    # AssertionError: if the oldString is not in the stringList.
    assert oldString in stringList, "The oldString must be in the list."
    for i in range(len(stringList)):
        if stringList[i] == oldString:
            stringList[i] = newString
    return stringList

def displayMenu():
    """
    Display the menu options for interacting with the stringList.
    """
    print("stringList:", stringList)
    print("1. Add String")
    print("2. Delete String")
    print("3. Search String")
    print("4. Replace String")
    print("0. Exit")
    
#Initialize the stringList
displayMenu()  
stringList = ["apple", "banana", "cherry", "apple"]
   #call the function
choice = input("Enter an option (0, 1, 2, 3, 4): ")  

#Iterate until the user input = 0
while choice!= '0':
    if choice == '1':
        string = input("Enter string to add: ")
        stringList = addString(stringList, string)
    elif choice == '2':
        string = input("Enter string to delete: ")
        stringList = deleteString(stringList, string)
    elif choice == '3':
        string = input("Enter string to search: ")
        positions = searchString(stringList, string)
        print("The position(s) of the string in the stringList is(are):", positions)
    elif choice == '4':
        oldString = input("Enter old string: ")
        newString = input("Enter new string: ")
        stringList = replaceString(stringList, oldString, newString)
    else:
        print("Error input, enter an option again!")   #Prompt the user wrong input
        choice = input("Choose an option (0, 1, 2, 3, 4): ")  
    # Redisplay the menu
    displayMenu()
    # Get user input again 
    choice = input("Enter an option (0, 1, 2, 3, 4): ")  
#which represents the program ends
print("Exit")
