def loadBooks():
    '''
    load book information from books.txt into variable
    '''
    bookContentList= []
    try:
        file = open("books.txt")
        lines = file.readlines()
        
        
        for eachline in lines:
            # remove eachline's leading and trailing space and split it use comma to get the information
            bookContent = eachline.strip().split(',')
            # add the book information to the blank list 
            bookContentList.append(bookContent)
            
    #assign the exception to variable error 
    except FileNotFoundError as error:  
        print('File not found', error)
    #except Exception as e:
        #print("Error", e)
    # will always execute   
    finally:
        # make sure won't close a file that donot exist
        if 'file' in locals():
            file.close()
    # return the list with information
    return bookContentList


def printBooks(books):
    '''
    print the information of each book in the list
    '''
    for book in books:
        print('book:', book[0], '-', book[1], '-',book[2])


def addBook(books):
    '''
    add a new book inforamtion to the list
    '''
    BookID = input('Enter Book ID: ')
    Title = input('Enter Book Title: ')
    Status = input('Enter Availability Status (available/borrowed): ')
    
    # if one of the 3 inputs is blank, execute the loop
    while BookID == '' or Title=='' or Status =='':
        print('Enter error, please enter again!')
        BookID = input('Enter Book ID: ')
        Title = input('Enter Book Title: ')
        Status = input('Enter Availability Status (available/borrowed): ')   
    books = books + [[BookID, Title, Status]]
    printBooks(books)
    return books


def deleteBook(books, BookID):
    '''
    delete a book information from the list based on its ID
    '''
    #change the integer BookID into string
    BookID = str(BookID)
    for book in books:
        if BookID == book[0]:
            books.remove(book)
    print('Book with ID', BookID, 'has been deleted.')
    # show the newest list
    printBooks(books)
    return books


def searchBook(books, Title):
    '''
    search for a book information based on its title
    '''
    found = False
    for book in books:
        if Title == book[1]:
            print('Book found:', book)
            found = True
    if not found:
        print('No book found with that title.')
    return books

def saveBooks(books):
    '''                 
    open a newfile called 'newBooks' and assign it to the variable newFile
    '''
    try:
        # file will automatically close after execute the content, mode'w' will overwrite the file                                                  
        with open('newBooks.txt', 'w') as newFile:
            for book in books:
                #bookContent = f"{book[0]},{book[1]},{book[2]}\n"
                bookContent = book[0]+","+book[1]+","+book[2]+"\n"
                newFile.write(bookContent)
            print('Save to file newBooks.txt correctly')
            
    except FileNotFoundError as error:
        print('File not found', error)


books = loadBooks()
printBooks(books)
books = addBook(books)
books = deleteBook(books, 103)
searchBook(books, "The Dream of the Red Chamber")
saveBooks(books)














