username = input("Enter username: ")
#Initialize Boolean variables judging the validity to true
rule1_valid,rule2_valid,rule3_valid,rule4_valid = True, True, True, True

# Rule 1:must contain only letters, numbers, and  (_).
for char in username:
    if not ('a' <= char <= 'z' or 'A' <= char <= 'Z' or '0' <= char <= '9' or char == '_'):
        rule1_valid = False
        
# Rule 2:must start with a letter.
if not ('a' <= username[0] <= 'z' or 'A' <= username[0] <= 'Z'):
    rule2_valid = False

#Rule 3:at least 5 characters long but not more than 15 characters long.
if len(username) < 5 or len(username) > 15:
    rule3_valid = False
    
#Rule 4: cannot contain consecutive underscores.
for i in range(len(username) - 1):
    #write"len(username) - 1" to make sure"username[i+1]"won't exceed the list
    if username[i] == '_' and username[i + 1] == '_':
        rule4_valid = False
        
if rule1_valid:
    print('True :',username ,'contains only valid characters')#satisfy rule1
else:
    print('False :',username ,'contains invalid characters')#dissatisfy rule1

if rule2_valid: 
    print('True :',username ,'starts with a letter')#satisfy rule2
else:
    print('False :',username ,'does not start with a letter')#dissatisfy rule2

if rule3_valid:
    print('True :',username, 'is of valid length')#satisfy rule3
else:
    print('False :',username, 'is not of valid length')#dissatisfy rule3

if rule4_valid:
    print('True :',username, 'does not contain consecutive underscores')#satisfy rule4
else:
    print('False :',username, 'contains consecutive underscores')#dissatisfy rule4

# Final validation result based on all rules
if rule1_valid and rule2_valid and rule3_valid and rule4_valid:
    print('Final Validation\n',username,' is a valid username',sep ="")
else:
    print('Final Validation\n',username,' is not a valid username',sep ="")










    
    
    
