

#Dice game for 5 people
def gameOver(scores):
    """ Return True if one of the score
    is more or equal to 100 """
    for score in scores:
        if score >=100:
            return True
    return False

def castDice():
    """ Return the value of 2 randomly casted dice,
    or 0 if any of the dice is 1,
    or -1 if both dice are 1 """
    import random
    die1 = random.randint(1,6)
    die2 = random.randint(1,6)
    points = 0
    print("die 1-->", die1, "Die2 -->", die2)
    #total of dice 1 + dice 2, 0 or -1 if both dice are 1
    if die1 == 1 and die2 == 1:
        points = -1
    elif die1 != 1 and die2 != 1:
        points = die1 + die2
    return points                                                                    



# Do we need to change this function? No          
def updateScore(score, points):
    """ Return the updated score with the points.
    Return 0 if the points is -1"""
    if points != -1:
        score += points
    else:
        score = 0
    return score
def displayWinner(scores):
    """ Display the player with the highest score,
    or if both have a tie """
    max_score = scores[0]
    winners = []
    for i in range(1, len(scores)):
        if scores[i] > max_score:
            max_score = scores[i]
            winners = [i + 1]
        elif scores[i] == max_score:
            winners.append(i + 1)
    if len(winners) == 1:
        print("The winner is player", winners[0])
    else:
        print("There is a tie between players: ", winners)
       
    #main program
num_players = 5
scores = [0] * num_players
while not gameOver(scores):
    for i in range(num_players):
        points = castDice()
        scores[i] = updateScore(scores[i], points)
        print("player ", i+1, "score: ", scores[i])
    print("=" * 50)
        
displayWinner(scores)   










